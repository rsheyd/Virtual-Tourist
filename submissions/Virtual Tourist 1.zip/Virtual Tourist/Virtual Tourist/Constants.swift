//
//  Constants.swift
//  On The Map
//
//  Created by Roman Sheydvasser on 4/5/17.
//  Copyright © 2017 RLabs. All rights reserved.
//

extension WebClient {
    struct Constants {
        static let flickrAPIKey = "7d9eeb6568c2637b23e2041a429d492d"
    }
}
